/* tslint:disable */
/* auto-generated angular directive proxies */
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, NgZone, EventEmitter, NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProxyCmp, proxyOutputs } from './angular-component-lib/utils';

import { Components } from '@baloise/design-system-components';
import { defineCustomElement as defineBalAccordion } from '@baloise/design-system-components/dist/components/bal-accordion';
import { defineCustomElement as defineBalApp } from '@baloise/design-system-components/dist/components/bal-app';
import { defineCustomElement as defineBalBadge } from '@baloise/design-system-components/dist/components/bal-badge';
import { defineCustomElement as defineBalButton } from '@baloise/design-system-components/dist/components/bal-button';
import { defineCustomElement as defineBalButtonGroup } from '@baloise/design-system-components/dist/components/bal-button-group';
import { defineCustomElement as defineBalCard } from '@baloise/design-system-components/dist/components/bal-card';
import { defineCustomElement as defineBalCardActions } from '@baloise/design-system-components/dist/components/bal-card-actions';
import { defineCustomElement as defineBalCardButton } from '@baloise/design-system-components/dist/components/bal-card-button';
import { defineCustomElement as defineBalCardContent } from '@baloise/design-system-components/dist/components/bal-card-content';
import { defineCustomElement as defineBalCardSubtitle } from '@baloise/design-system-components/dist/components/bal-card-subtitle';
import { defineCustomElement as defineBalCardTitle } from '@baloise/design-system-components/dist/components/bal-card-title';
import { defineCustomElement as defineBalCheckbox } from '@baloise/design-system-components/dist/components/bal-checkbox';
import { defineCustomElement as defineBalCheckboxGroup } from '@baloise/design-system-components/dist/components/bal-checkbox-group';
import { defineCustomElement as defineBalClose } from '@baloise/design-system-components/dist/components/bal-close';
import { defineCustomElement as defineBalData } from '@baloise/design-system-components/dist/components/bal-data';
import { defineCustomElement as defineBalDataItem } from '@baloise/design-system-components/dist/components/bal-data-item';
import { defineCustomElement as defineBalDataLabel } from '@baloise/design-system-components/dist/components/bal-data-label';
import { defineCustomElement as defineBalDataValue } from '@baloise/design-system-components/dist/components/bal-data-value';
import { defineCustomElement as defineBalDatepicker } from '@baloise/design-system-components/dist/components/bal-datepicker';
import { defineCustomElement as defineBalField } from '@baloise/design-system-components/dist/components/bal-field';
import { defineCustomElement as defineBalFieldControl } from '@baloise/design-system-components/dist/components/bal-field-control';
import { defineCustomElement as defineBalFieldHint } from '@baloise/design-system-components/dist/components/bal-field-hint';
import { defineCustomElement as defineBalFieldLabel } from '@baloise/design-system-components/dist/components/bal-field-label';
import { defineCustomElement as defineBalFieldMessage } from '@baloise/design-system-components/dist/components/bal-field-message';
import { defineCustomElement as defineBalFileUpload } from '@baloise/design-system-components/dist/components/bal-file-upload';
import { defineCustomElement as defineBalFooter } from '@baloise/design-system-components/dist/components/bal-footer';
import { defineCustomElement as defineBalHeading } from '@baloise/design-system-components/dist/components/bal-heading';
import { defineCustomElement as defineBalHint } from '@baloise/design-system-components/dist/components/bal-hint';
import { defineCustomElement as defineBalHintText } from '@baloise/design-system-components/dist/components/bal-hint-text';
import { defineCustomElement as defineBalHintTitle } from '@baloise/design-system-components/dist/components/bal-hint-title';
import { defineCustomElement as defineBalIcon } from '@baloise/design-system-components/dist/components/bal-icon';
import { defineCustomElement as defineBalInput } from '@baloise/design-system-components/dist/components/bal-input';
import { defineCustomElement as defineBalInputGroup } from '@baloise/design-system-components/dist/components/bal-input-group';
import { defineCustomElement as defineBalInputStepper } from '@baloise/design-system-components/dist/components/bal-input-stepper';
import { defineCustomElement as defineBalList } from '@baloise/design-system-components/dist/components/bal-list';
import { defineCustomElement as defineBalListItem } from '@baloise/design-system-components/dist/components/bal-list-item';
import { defineCustomElement as defineBalListItemContent } from '@baloise/design-system-components/dist/components/bal-list-item-content';
import { defineCustomElement as defineBalListItemIcon } from '@baloise/design-system-components/dist/components/bal-list-item-icon';
import { defineCustomElement as defineBalListItemSubtitle } from '@baloise/design-system-components/dist/components/bal-list-item-subtitle';
import { defineCustomElement as defineBalListItemTitle } from '@baloise/design-system-components/dist/components/bal-list-item-title';
import { defineCustomElement as defineBalLogo } from '@baloise/design-system-components/dist/components/bal-logo';
import { defineCustomElement as defineBalModal } from '@baloise/design-system-components/dist/components/bal-modal';
import { defineCustomElement as defineBalModalBody } from '@baloise/design-system-components/dist/components/bal-modal-body';
import { defineCustomElement as defineBalModalHeader } from '@baloise/design-system-components/dist/components/bal-modal-header';
import { defineCustomElement as defineBalNavbar } from '@baloise/design-system-components/dist/components/bal-navbar';
import { defineCustomElement as defineBalNavbarBrand } from '@baloise/design-system-components/dist/components/bal-navbar-brand';
import { defineCustomElement as defineBalNavbarMenu } from '@baloise/design-system-components/dist/components/bal-navbar-menu';
import { defineCustomElement as defineBalNavbarMenuEnd } from '@baloise/design-system-components/dist/components/bal-navbar-menu-end';
import { defineCustomElement as defineBalNavbarMenuStart } from '@baloise/design-system-components/dist/components/bal-navbar-menu-start';
import { defineCustomElement as defineBalNotices } from '@baloise/design-system-components/dist/components/bal-notices';
import { defineCustomElement as defineBalNotification } from '@baloise/design-system-components/dist/components/bal-notification';
import { defineCustomElement as defineBalNumberInput } from '@baloise/design-system-components/dist/components/bal-number-input';
import { defineCustomElement as defineBalPagination } from '@baloise/design-system-components/dist/components/bal-pagination';
import { defineCustomElement as defineBalPopover } from '@baloise/design-system-components/dist/components/bal-popover';
import { defineCustomElement as defineBalPopoverContent } from '@baloise/design-system-components/dist/components/bal-popover-content';
import { defineCustomElement as defineBalRadio } from '@baloise/design-system-components/dist/components/bal-radio';
import { defineCustomElement as defineBalRadioGroup } from '@baloise/design-system-components/dist/components/bal-radio-group';
import { defineCustomElement as defineBalSelect } from '@baloise/design-system-components/dist/components/bal-select';
import { defineCustomElement as defineBalSelectOption } from '@baloise/design-system-components/dist/components/bal-select-option';
import { defineCustomElement as defineBalSheet } from '@baloise/design-system-components/dist/components/bal-sheet';
import { defineCustomElement as defineBalSlider } from '@baloise/design-system-components/dist/components/bal-slider';
import { defineCustomElement as defineBalSnackbar } from '@baloise/design-system-components/dist/components/bal-snackbar';
import { defineCustomElement as defineBalSpinner } from '@baloise/design-system-components/dist/components/bal-spinner';
import { defineCustomElement as defineBalStage } from '@baloise/design-system-components/dist/components/bal-stage';
import { defineCustomElement as defineBalStageBody } from '@baloise/design-system-components/dist/components/bal-stage-body';
import { defineCustomElement as defineBalStageFoot } from '@baloise/design-system-components/dist/components/bal-stage-foot';
import { defineCustomElement as defineBalStageHead } from '@baloise/design-system-components/dist/components/bal-stage-head';
import { defineCustomElement as defineBalStageImage } from '@baloise/design-system-components/dist/components/bal-stage-image';
import { defineCustomElement as defineBalTabItem } from '@baloise/design-system-components/dist/components/bal-tab-item';
import { defineCustomElement as defineBalTable } from '@baloise/design-system-components/dist/components/bal-table';
import { defineCustomElement as defineBalTabs } from '@baloise/design-system-components/dist/components/bal-tabs';
import { defineCustomElement as defineBalTag } from '@baloise/design-system-components/dist/components/bal-tag';
import { defineCustomElement as defineBalText } from '@baloise/design-system-components/dist/components/bal-text';
import { defineCustomElement as defineBalTextarea } from '@baloise/design-system-components/dist/components/bal-textarea';
import { defineCustomElement as defineBalTimeinput } from '@baloise/design-system-components/dist/components/bal-timeinput';
import { defineCustomElement as defineBalToast } from '@baloise/design-system-components/dist/components/bal-toast';


export declare interface BalAccordion extends Components.BalAccordion {}
@ProxyCmp({
  inputs: ['card', 'closeIcon', 'closeLabel', 'color', 'debounce', 'openIcon', 'openLabel', 'value'],
  methods: ['present', 'dismiss', 'toggle']
})
@Component({
  selector: 'bal-accordion',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['card', 'closeIcon', 'closeLabel', 'color', 'debounce', 'openIcon', 'openLabel', 'value'],
  outputs: ['balChange']
})
export class BalAccordion {
  /** Emitted when the accordion has changed */
  balChange!: EventEmitter<CustomEvent<boolean>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange']);
  }
}


export declare interface BalApp extends Components.BalApp {}

@Component({
  selector: 'bal-app',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalApp {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalBadge extends Components.BalBadge {}
@ProxyCmp({
  inputs: ['color', 'icon', 'position', 'size']
})
@Component({
  selector: 'bal-badge',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color', 'icon', 'position', 'size']
})
export class BalBadge {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalButton extends Components.BalButton {}
@ProxyCmp({
  inputs: ['bottomRounded', 'color', 'disabled', 'download', 'expanded', 'href', 'icon', 'iconPosition', 'iconRight', 'inverted', 'isActive', 'loading', 'name', 'outlined', 'rel', 'size', 'square', 'target', 'topRounded', 'type', 'value']
})
@Component({
  selector: 'bal-button',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['bottomRounded', 'color', 'disabled', 'download', 'expanded', 'href', 'icon', 'iconPosition', 'iconRight', 'inverted', 'isActive', 'loading', 'name', 'outlined', 'rel', 'size', 'square', 'target', 'topRounded', 'type', 'value'],
  outputs: ['balNavigate', 'balFocus', 'balBlur', 'balDidRender']
})
export class BalButton {
  /** Emitted when the link element has clicked. */
  balNavigate!: EventEmitter<CustomEvent<MouseEvent>>;
  /** Emitted when the button has focus. */
  balFocus!: EventEmitter<CustomEvent<void>>;
  /** Emitted when the button loses focus. */
  balBlur!: EventEmitter<CustomEvent<void>>;
  /** Emitted when the button has been  rendered. */
  balDidRender!: EventEmitter<CustomEvent<void>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balNavigate', 'balFocus', 'balBlur', 'balDidRender']);
  }
}


export declare interface BalButtonGroup extends Components.BalButtonGroup {}
@ProxyCmp({
  inputs: ['position']
})
@Component({
  selector: 'bal-button-group',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['position']
})
export class BalButtonGroup {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCard extends Components.BalCard {}
@ProxyCmp({
  inputs: ['border', 'color', 'flat', 'inverted', 'square']
})
@Component({
  selector: 'bal-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['border', 'color', 'flat', 'inverted', 'square']
})
export class BalCard {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCardActions extends Components.BalCardActions {}
@ProxyCmp({
  inputs: ['position', 'right']
})
@Component({
  selector: 'bal-card-actions',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['position', 'right']
})
export class BalCardActions {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCardButton extends Components.BalCardButton {}
@ProxyCmp({
  inputs: ['disabled', 'href', 'icon', 'iconRight', 'loading', 'target', 'type']
})
@Component({
  selector: 'bal-card-button',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'href', 'icon', 'iconRight', 'loading', 'target', 'type']
})
export class BalCardButton {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCardContent extends Components.BalCardContent {}

@Component({
  selector: 'bal-card-content',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalCardContent {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCardSubtitle extends Components.BalCardSubtitle {}
@ProxyCmp({
  inputs: ['inverted']
})
@Component({
  selector: 'bal-card-subtitle',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['inverted']
})
export class BalCardSubtitle {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCardTitle extends Components.BalCardTitle {}
@ProxyCmp({
  inputs: ['inverted']
})
@Component({
  selector: 'bal-card-title',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['inverted']
})
export class BalCardTitle {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalCheckbox extends Components.BalCheckbox {}
@ProxyCmp({
  inputs: ['checked', 'disabled', 'hidden', 'interface', 'inverted', 'labelHidden', 'name', 'value'],
  methods: ['setFocus', 'getInputElement']
})
@Component({
  selector: 'bal-checkbox',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['checked', 'disabled', 'hidden', 'interface', 'inverted', 'labelHidden', 'name', 'value'],
  outputs: ['balChange', 'balFocus', 'balBlur', 'balClick']
})
export class BalCheckbox {
  /** Emitted when the checked property has changed. */
  balChange!: EventEmitter<CustomEvent<boolean>>;
  /** Emitted when the toggle has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the toggle loses focus. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balFocus', 'balBlur', 'balClick']);
  }
}


export declare interface BalCheckboxGroup extends Components.BalCheckboxGroup {}
@ProxyCmp({
  inputs: ['vertical']
})
@Component({
  selector: 'bal-checkbox-group',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['vertical']
})
export class BalCheckboxGroup {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalClose extends Components.BalClose {}
@ProxyCmp({
  inputs: ['background', 'inverted', 'size']
})
@Component({
  selector: 'bal-close',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['background', 'inverted', 'size']
})
export class BalClose {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalData extends Components.BalData {}
@ProxyCmp({
  inputs: ['border', 'horizontal']
})
@Component({
  selector: 'bal-data',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['border', 'horizontal']
})
export class BalData {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalDataItem extends Components.BalDataItem {}
@ProxyCmp({
  inputs: ['disabled']
})
@Component({
  selector: 'bal-data-item',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled']
})
export class BalDataItem {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalDataLabel extends Components.BalDataLabel {}
@ProxyCmp({
  inputs: ['required']
})
@Component({
  selector: 'bal-data-label',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['required']
})
export class BalDataLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalDataValue extends Components.BalDataValue {}
@ProxyCmp({
  inputs: ['disabled', 'editable']
})
@Component({
  selector: 'bal-data-value',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'editable'],
  outputs: ['balClick', 'balFocus', 'balBlur']
})
export class BalDataValue {
  /** Emitted when the edit button has focus. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  /** Emitted when the edit button has focus. */
  balFocus!: EventEmitter<CustomEvent<void>>;
  /** Emitted when the edit button loses focus. */
  balBlur!: EventEmitter<CustomEvent<void>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balClick', 'balFocus', 'balBlur']);
  }
}


export declare interface BalDatepicker extends Components.BalDatepicker {}
@ProxyCmp({
  inputs: ['allowedDates', 'closeOnSelect', 'debounce', 'defaultDate', 'disabled', 'invalid', 'inverted', 'locale', 'max', 'maxYearProp', 'min', 'minYearProp', 'name', 'placeholder', 'readonly', 'required', 'triggerIcon', 'value'],
  methods: ['open', 'close', 'select', 'setFocus', 'getInputElement']
})
@Component({
  selector: 'bal-datepicker',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['allowedDates', 'closeOnSelect', 'debounce', 'defaultDate', 'disabled', 'invalid', 'inverted', 'locale', 'max', 'maxYearProp', 'min', 'minYearProp', 'name', 'placeholder', 'readonly', 'required', 'triggerIcon', 'value'],
  outputs: ['balChange', 'balInput', 'balBlur', 'balFocus', 'balClick']
})
export class BalDatepicker {
  /** Emitted when a option got selected. */
  balChange!: EventEmitter<CustomEvent<string | undefined>>;
  /** Emitted when a keyboard input occurred. */
  balInput!: EventEmitter<CustomEvent<string | undefined>>;
  /** Emitted when the input loses focus. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balInput', 'balBlur', 'balFocus', 'balClick']);
  }
}


export declare interface BalField extends Components.BalField {}
@ProxyCmp({
  inputs: ['disabled', 'invalid', 'inverted', 'loading']
})
@Component({
  selector: 'bal-field',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'invalid', 'inverted', 'loading']
})
export class BalField {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalFieldControl extends Components.BalFieldControl {}
@ProxyCmp({
  inputs: ['iconLeft', 'iconRight', 'invalid', 'inverted', 'loading']
})
@Component({
  selector: 'bal-field-control',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['iconLeft', 'iconRight', 'invalid', 'inverted', 'loading']
})
export class BalFieldControl {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalFieldHint extends Components.BalFieldHint {}
@ProxyCmp({
  inputs: ['closeLabel', 'small', 'subject']
})
@Component({
  selector: 'bal-field-hint',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['closeLabel', 'small', 'subject']
})
export class BalFieldHint {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalFieldLabel extends Components.BalFieldLabel {}
@ProxyCmp({
  inputs: ['invalid', 'required']
})
@Component({
  selector: 'bal-field-label',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['invalid', 'required']
})
export class BalFieldLabel {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalFieldMessage extends Components.BalFieldMessage {}
@ProxyCmp({
  inputs: ['color', 'invalid']
})
@Component({
  selector: 'bal-field-message',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color', 'invalid']
})
export class BalFieldMessage {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

import { FileUploadRejectedFile } from '@baloise/design-system-components';
export declare interface BalFileUpload extends Components.BalFileUpload {}
@ProxyCmp({
  inputs: ['accept', 'disabled', 'hasFileList', 'label', 'maxBundleSize', 'maxFileSize', 'maxFiles', 'multiple', 'subTitle', 'value'],
  methods: ['clear']
})
@Component({
  selector: 'bal-file-upload',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['accept', 'disabled', 'hasFileList', 'label', 'maxBundleSize', 'maxFileSize', 'maxFiles', 'multiple', 'subTitle', 'value'],
  outputs: ['balChange', 'balRejectedFile']
})
export class BalFileUpload {
  /** Triggers when a file is added or removed. */
  balChange!: EventEmitter<CustomEvent<File[]>>;
  /** Triggers when a file is rejected due to not allowed MIME-Type and so on. */
  balRejectedFile!: EventEmitter<CustomEvent<FileUploadRejectedFile>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balRejectedFile']);
  }
}


export declare interface BalFooter extends Components.BalFooter {}
@ProxyCmp({
  inputs: ['hasTrackLine', 'hideLanguageSelection', 'hideLinks', 'locale']
})
@Component({
  selector: 'bal-footer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['hasTrackLine', 'hideLanguageSelection', 'hideLinks', 'locale']
})
export class BalFooter {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalHeading extends Components.BalHeading {}
@ProxyCmp({
  inputs: ['color', 'inverted', 'level', 'space', 'subtitle', 'visualLevel']
})
@Component({
  selector: 'bal-heading',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color', 'inverted', 'level', 'space', 'subtitle', 'visualLevel']
})
export class BalHeading {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalHint extends Components.BalHint {}
@ProxyCmp({
  inputs: ['closeLabel', 'small'],
  methods: ['toggle', 'present', 'dismiss']
})
@Component({
  selector: 'bal-hint',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['closeLabel', 'small']
})
export class BalHint {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalHintText extends Components.BalHintText {}

@Component({
  selector: 'bal-hint-text',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalHintText {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalHintTitle extends Components.BalHintTitle {}

@Component({
  selector: 'bal-hint-title',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalHintTitle {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalIcon extends Components.BalIcon {}
@ProxyCmp({
  inputs: ['color', 'inverted', 'name', 'rotate', 'size', 'svg', 'turn']
})
@Component({
  selector: 'bal-icon',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color', 'inverted', 'name', 'rotate', 'size', 'svg', 'turn']
})
export class BalIcon {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalInput extends Components.BalInput {}
@ProxyCmp({
  inputs: ['accept', 'autocapitalize', 'autocomplete', 'autocorrect', 'autofocus', 'clickable', 'debounce', 'decimal', 'disabled', 'inputmode', 'invalid', 'inverted', 'max', 'maxLength', 'min', 'minLength', 'multiple', 'name', 'numberInput', 'pattern', 'placeholder', 'readonly', 'required', 'spellcheck', 'suffix', 'type', 'value'],
  methods: ['setFocus', 'getInputElement']
})
@Component({
  selector: 'bal-input',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['accept', 'autocapitalize', 'autocomplete', 'autocorrect', 'autofocus', 'clickable', 'debounce', 'decimal', 'disabled', 'inputmode', 'invalid', 'inverted', 'max', 'maxLength', 'min', 'minLength', 'multiple', 'name', 'numberInput', 'pattern', 'placeholder', 'readonly', 'required', 'spellcheck', 'suffix', 'type', 'value'],
  outputs: ['balInput', 'balBlur', 'balClick', 'balKeyPress', 'balFocus', 'balChange']
})
export class BalInput {
  /** Emitted when a keyboard input occurred. */
  balInput!: EventEmitter<CustomEvent<string | undefined>>;
  /** Emitted when a keyboard input occurred. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  /** Emitted when a keyboard key has pressed. */
  balKeyPress!: EventEmitter<CustomEvent<KeyboardEvent>>;
  /** Emitted when the input has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input value has changed. */
  balChange!: EventEmitter<CustomEvent<string | undefined>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balInput', 'balBlur', 'balClick', 'balKeyPress', 'balFocus', 'balChange']);
  }
}


export declare interface BalInputGroup extends Components.BalInputGroup {}
@ProxyCmp({
  inputs: ['disabled', 'invalid']
})
@Component({
  selector: 'bal-input-group',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'invalid']
})
export class BalInputGroup {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalInputStepper extends Components.BalInputStepper {}
@ProxyCmp({
  inputs: ['debounce', 'disabled', 'invalid', 'max', 'min', 'name', 'steps', 'value'],
  methods: ['getInputElement']
})
@Component({
  selector: 'bal-input-stepper',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['debounce', 'disabled', 'invalid', 'max', 'min', 'name', 'steps', 'value'],
  outputs: ['balChange', 'balInput']
})
export class BalInputStepper {
  /** Emitted when the input value has changed. */
  balChange!: EventEmitter<CustomEvent<number | undefined>>;
  /** Emitted when the input value has changed. */
  balInput!: EventEmitter<CustomEvent<number | undefined>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balInput']);
  }
}


export declare interface BalList extends Components.BalList {}
@ProxyCmp({
  inputs: ['border', 'disabled', 'inverted', 'size']
})
@Component({
  selector: 'bal-list',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['border', 'disabled', 'inverted', 'size']
})
export class BalList {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalListItem extends Components.BalListItem {}
@ProxyCmp({
  inputs: ['clickable', 'disabled', 'href', 'selected', 'target']
})
@Component({
  selector: 'bal-list-item',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['clickable', 'disabled', 'href', 'selected', 'target'],
  outputs: ['balNavigate']
})
export class BalListItem {
  /** Emitted when the link element has clicked */
  balNavigate!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balNavigate']);
  }
}


export declare interface BalListItemContent extends Components.BalListItemContent {}

@Component({
  selector: 'bal-list-item-content',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalListItemContent {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalListItemIcon extends Components.BalListItemIcon {}
@ProxyCmp({
  inputs: ['right']
})
@Component({
  selector: 'bal-list-item-icon',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['right']
})
export class BalListItemIcon {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalListItemSubtitle extends Components.BalListItemSubtitle {}

@Component({
  selector: 'bal-list-item-subtitle',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalListItemSubtitle {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalListItemTitle extends Components.BalListItemTitle {}

@Component({
  selector: 'bal-list-item-title',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalListItemTitle {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalLogo extends Components.BalLogo {}
@ProxyCmp({
  inputs: ['brand', 'color']
})
@Component({
  selector: 'bal-logo',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['brand', 'color']
})
export class BalLogo {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}

import { OverlayEventDetail } from '@baloise/design-system-components';
export declare interface BalModal extends Components.BalModal {}
@ProxyCmp({
  inputs: ['component', 'componentProps', 'cssClass', 'hasBackdrop', 'interface', 'isClosable', 'modalWidth'],
  methods: ['present', 'dismiss', 'onDidDismiss', 'onWillDismiss']
})
@Component({
  selector: 'bal-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['component', 'componentProps', 'cssClass', 'hasBackdrop', 'interface', 'isClosable', 'modalWidth'],
  outputs: ['balModalDidPresent', 'balModalWillPresent', 'balModalWillDismiss', 'balModalDidDismiss']
})
export class BalModal {
  /** Emitted after the modal has presented. */
  balModalDidPresent!: EventEmitter<CustomEvent<void>>;
  /** Emitted before the modal has presented. */
  balModalWillPresent!: EventEmitter<CustomEvent<void>>;
  /** Emitted before the modal has dismissed. */
  balModalWillDismiss!: EventEmitter<CustomEvent<OverlayEventDetail<any>>>;
  /** Emitted after the modal has dismissed. */
  balModalDidDismiss!: EventEmitter<CustomEvent<OverlayEventDetail<any>>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balModalDidPresent', 'balModalWillPresent', 'balModalWillDismiss', 'balModalDidDismiss']);
  }
}


export declare interface BalModalBody extends Components.BalModalBody {}

@Component({
  selector: 'bal-modal-body',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalModalBody {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalModalHeader extends Components.BalModalHeader {}

@Component({
  selector: 'bal-modal-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalModalHeader {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNavbar extends Components.BalNavbar {}
@ProxyCmp({
  inputs: ['expanded', 'light', 'noBurger']
})
@Component({
  selector: 'bal-navbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['expanded', 'light', 'noBurger']
})
export class BalNavbar {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNavbarBrand extends Components.BalNavbarBrand {}
@ProxyCmp({
  inputs: ['href', 'simple']
})
@Component({
  selector: 'bal-navbar-brand',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['href', 'simple'],
  outputs: ['balNavigate']
})
export class BalNavbarBrand {
  /** Emitted when the link element has clicked */
  balNavigate!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balNavigate']);
  }
}


export declare interface BalNavbarMenu extends Components.BalNavbarMenu {}

@Component({
  selector: 'bal-navbar-menu',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalNavbarMenu {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNavbarMenuEnd extends Components.BalNavbarMenuEnd {}

@Component({
  selector: 'bal-navbar-menu-end',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalNavbarMenuEnd {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNavbarMenuStart extends Components.BalNavbarMenuStart {}

@Component({
  selector: 'bal-navbar-menu-start',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalNavbarMenuStart {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNotices extends Components.BalNotices {}
@ProxyCmp({
  inputs: ['interface']
})
@Component({
  selector: 'bal-notices',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['interface']
})
export class BalNotices {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNotification extends Components.BalNotification {}
@ProxyCmp({
  inputs: ['color']
})
@Component({
  selector: 'bal-notification',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color']
})
export class BalNotification {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalNumberInput extends Components.BalNumberInput {}
@ProxyCmp({
  inputs: ['debounce', 'decimal', 'disabled', 'invalid', 'name', 'placeholder', 'readonly', 'required', 'suffix', 'value'],
  methods: ['setFocus', 'getInputElement']
})
@Component({
  selector: 'bal-number-input',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['debounce', 'decimal', 'disabled', 'invalid', 'name', 'placeholder', 'readonly', 'required', 'suffix', 'value'],
  outputs: ['balInput', 'balChange', 'balBlur', 'balFocus', 'balKeyPress', 'balClick']
})
export class BalNumberInput {
  /** Emitted when a keyboard input occurred. */
  balInput!: EventEmitter<CustomEvent<number | undefined>>;
  /** Emitted when the value has changed. */
  balChange!: EventEmitter<CustomEvent<number | undefined>>;
  /** Emitted when the input loses focus. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when a keyboard key has pressed. */
  balKeyPress!: EventEmitter<CustomEvent<KeyboardEvent>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balInput', 'balChange', 'balBlur', 'balFocus', 'balKeyPress', 'balClick']);
  }
}


export declare interface BalPagination extends Components.BalPagination {}
@ProxyCmp({
  inputs: ['disabled', 'pageRange', 'totalPages', 'value'],
  methods: ['next', 'previous']
})
@Component({
  selector: 'bal-pagination',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'pageRange', 'totalPages', 'value'],
  outputs: ['balChange']
})
export class BalPagination {
  /** Triggers when a page change happens */
  balChange!: EventEmitter<CustomEvent<number>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange']);
  }
}


export declare interface BalPopover extends Components.BalPopover {}
@ProxyCmp({
  inputs: ['debounce', 'offsetX', 'offsetY', 'position', 'value'],
  methods: ['present', 'dismiss', 'toggle']
})
@Component({
  selector: 'bal-popover',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['debounce', 'offsetX', 'offsetY', 'position', 'value'],
  outputs: ['balChange']
})
export class BalPopover {
  /** Listen when the popover opens or closes. Returns the current value. */
  balChange!: EventEmitter<CustomEvent<boolean>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange']);
  }
}


export declare interface BalPopoverContent extends Components.BalPopoverContent {}
@ProxyCmp({
  inputs: ['contentWidth', 'scrollable']
})
@Component({
  selector: 'bal-popover-content',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['contentWidth', 'scrollable']
})
export class BalPopoverContent {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalRadio extends Components.BalRadio {}
@ProxyCmp({
  inputs: ['checked', 'disabled', 'interface', 'inverted', 'isEmpty', 'labelHidden', 'name', 'value'],
  methods: ['setFocus']
})
@Component({
  selector: 'bal-radio',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['checked', 'disabled', 'interface', 'inverted', 'isEmpty', 'labelHidden', 'name', 'value'],
  outputs: ['balFocus', 'balBlur', 'balChange', 'balClick']
})
export class BalRadio {
  /** Emitted when the toggle has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the toggle loses focus. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the checked property has changed. */
  balChange!: EventEmitter<CustomEvent<boolean>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balFocus', 'balBlur', 'balChange', 'balClick']);
  }
}


export declare interface BalRadioGroup extends Components.BalRadioGroup {}
@ProxyCmp({
  inputs: ['disabled', 'interface', 'inverted', 'name', 'value', 'vertical', 'verticalOnMobile']
})
@Component({
  selector: 'bal-radio-group',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'interface', 'inverted', 'name', 'value', 'vertical', 'verticalOnMobile'],
  outputs: ['balChange']
})
export class BalRadioGroup {
  /** Emitted when the checked property has changed. */
  balChange!: EventEmitter<CustomEvent<string>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange']);
  }
}


export declare interface BalSelect extends Components.BalSelect {}
@ProxyCmp({
  inputs: ['balTabindex', 'disabled', 'hasMovement', 'invalid', 'inverted', 'loading', 'multiple', 'name', 'noBorder', 'noDataLabel', 'placeholder', 'scrollable', 'typeahead', 'value'],
  methods: ['setFocus', 'getValue', 'clear', 'open', 'close', 'cancel', 'select']
})
@Component({
  selector: 'bal-select',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['balTabindex', 'disabled', 'hasMovement', 'invalid', 'inverted', 'loading', 'multiple', 'name', 'noBorder', 'noDataLabel', 'placeholder', 'scrollable', 'typeahead', 'value'],
  outputs: ['balChange', 'balClick', 'balInput', 'balBlur', 'balFocus', 'balCancel', 'balKeyPress']
})
export class BalSelect {
  /** Emitted when a option got selected. */
  balChange!: EventEmitter<CustomEvent<string | string[] | undefined>>;
  /** Emitted when the input got clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  /** Emitted when a keyboard input occurred. */
  balInput!: EventEmitter<CustomEvent<string>>;
  /** Emitted when the input loses focus. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the user cancels the input. */
  balCancel!: EventEmitter<CustomEvent<KeyboardEvent>>;
  /** Emitted when the input has focus and key from the keyboard go hit. */
  balKeyPress!: EventEmitter<CustomEvent<KeyboardEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balClick', 'balInput', 'balBlur', 'balFocus', 'balCancel', 'balKeyPress']);
  }
}


export declare interface BalSelectOption extends Components.BalSelectOption {}
@ProxyCmp({
  inputs: ['disabled', 'label', 'value']
})
@Component({
  selector: 'bal-select-option',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'label', 'value']
})
export class BalSelectOption {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalSheet extends Components.BalSheet {}

@Component({
  selector: 'bal-sheet',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalSheet {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalSlider extends Components.BalSlider {}
@ProxyCmp({
  inputs: ['balTabindex', 'debounce', 'disabled', 'hasTicks', 'max', 'min', 'name', 'readonly', 'required', 'step', 'value'],
  methods: ['setFocus', 'getInputElement']
})
@Component({
  selector: 'bal-slider',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['balTabindex', 'debounce', 'disabled', 'hasTicks', 'max', 'min', 'name', 'readonly', 'required', 'step', 'value'],
  outputs: ['balInput', 'balBlur', 'balClick', 'balKeyPress', 'balFocus', 'balChange']
})
export class BalSlider {
  /** Emitted when a keyboard input occurred. */
  balInput!: EventEmitter<CustomEvent<null | number | string>>;
  /** Emitted when a keyboard input occurred. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  /** Emitted when a keyboard key has pressed. */
  balKeyPress!: EventEmitter<CustomEvent<KeyboardEvent>>;
  /** Emitted when the input has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input value has changed. */
  balChange!: EventEmitter<CustomEvent<null | number | string>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balInput', 'balBlur', 'balClick', 'balKeyPress', 'balFocus', 'balChange']);
  }
}


export declare interface BalSnackbar extends Components.BalSnackbar {}
@ProxyCmp({
  inputs: ['action', 'color', 'duration', 'icon', 'message', 'subject'],
  methods: ['closeIn', 'close']
})
@Component({
  selector: 'bal-snackbar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['action', 'color', 'duration', 'icon', 'message', 'subject'],
  outputs: ['balClose', 'balAction']
})
export class BalSnackbar {
  /** Emitted when snackbar is closed */
  balClose!: EventEmitter<CustomEvent<string>>;
  /** Emitted when the action button is clicked */
  balAction!: EventEmitter<CustomEvent<string>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balClose', 'balAction']);
  }
}


export declare interface BalSpinner extends Components.BalSpinner {}
@ProxyCmp({
  inputs: ['inverted', 'small']
})
@Component({
  selector: 'bal-spinner',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['inverted', 'small']
})
export class BalSpinner {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalStage extends Components.BalStage {}
@ProxyCmp({
  inputs: ['color', 'size']
})
@Component({
  selector: 'bal-stage',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color', 'size']
})
export class BalStage {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalStageBody extends Components.BalStageBody {}
@ProxyCmp({
  inputs: ['compact']
})
@Component({
  selector: 'bal-stage-body',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['compact']
})
export class BalStageBody {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalStageFoot extends Components.BalStageFoot {}

@Component({
  selector: 'bal-stage-foot',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalStageFoot {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalStageHead extends Components.BalStageHead {}

@Component({
  selector: 'bal-stage-head',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>'
})
export class BalStageHead {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalStageImage extends Components.BalStageImage {}
@ProxyCmp({
  inputs: ['src']
})
@Component({
  selector: 'bal-stage-image',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['src']
})
export class BalStageImage {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalTabItem extends Components.BalTabItem {}
@ProxyCmp({
  inputs: ['active', 'bubble', 'disabled', 'done', 'failed', 'href', 'label', 'prevent', 'value'],
  methods: ['getOptions', 'setActive']
})
@Component({
  selector: 'bal-tab-item',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['active', 'bubble', 'disabled', 'done', 'failed', 'href', 'label', 'prevent', 'value'],
  outputs: ['balNavigate']
})
export class BalTabItem {
  /** Emitted when the link element has clicked */
  balNavigate!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balNavigate']);
  }
}


export declare interface BalTable extends Components.BalTable {}
@ProxyCmp({
  inputs: ['expanded']
})
@Component({
  selector: 'bal-table',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['expanded']
})
export class BalTable {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalTabs extends Components.BalTabs {}
@ProxyCmp({
  inputs: ['action', 'actionLabel', 'clickable', 'debounce', 'expanded', 'interface', 'value'],
  methods: ['select']
})
@Component({
  selector: 'bal-tabs',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['action', 'actionLabel', 'clickable', 'debounce', 'expanded', 'interface', 'value'],
  outputs: ['balChange', 'balActionClick']
})
export class BalTabs {
  /** Emitted when the changes has finished. */
  balChange!: EventEmitter<CustomEvent<string>>;
  /** Emitted when the action button has clicked */
  balActionClick!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balActionClick']);
  }
}


export declare interface BalTag extends Components.BalTag {}
@ProxyCmp({
  inputs: ['closable', 'color', 'light', 'size']
})
@Component({
  selector: 'bal-tag',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['closable', 'color', 'light', 'size'],
  outputs: ['balCloseClick']
})
export class BalTag {
  /** Emitted when the input got clicked. */
  balCloseClick!: EventEmitter<CustomEvent<MouseEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balCloseClick']);
  }
}


export declare interface BalText extends Components.BalText {}
@ProxyCmp({
  inputs: ['bold', 'color', 'small']
})
@Component({
  selector: 'bal-text',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['bold', 'color', 'small']
})
export class BalText {
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
  }
}


export declare interface BalTextarea extends Components.BalTextarea {}
@ProxyCmp({
  inputs: ['autocapitalize', 'autofocus', 'clickable', 'cols', 'debounce', 'disabled', 'inputmode', 'invalid', 'inverted', 'maxLength', 'minLength', 'name', 'placeholder', 'readonly', 'required', 'rows', 'value', 'wrap'],
  methods: ['setFocus', 'getInputElement']
})
@Component({
  selector: 'bal-textarea',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['autocapitalize', 'autofocus', 'clickable', 'cols', 'debounce', 'disabled', 'inputmode', 'invalid', 'inverted', 'maxLength', 'minLength', 'name', 'placeholder', 'readonly', 'required', 'rows', 'value', 'wrap'],
  outputs: ['balChange', 'balInput', 'balBlur', 'balClick', 'balKeyPress', 'balFocus']
})
export class BalTextarea {
  /** Emitted when the input value has changed.. */
  balChange!: EventEmitter<CustomEvent<string | undefined>>;
  /** Emitted when a keyboard input occurred. */
  balInput!: EventEmitter<CustomEvent<string | undefined>>;
  /** Emitted when a keyboard input occurred. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  /** Emitted when the input has clicked. */
  balClick!: EventEmitter<CustomEvent<MouseEvent>>;
  /** Emitted when a keyboard key has pressed. */
  balKeyPress!: EventEmitter<CustomEvent<KeyboardEvent>>;
  /** Emitted when the input has focus. */
  balFocus!: EventEmitter<CustomEvent<FocusEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balInput', 'balBlur', 'balClick', 'balKeyPress', 'balFocus']);
  }
}


export declare interface BalTimeinput extends Components.BalTimeinput {}
@ProxyCmp({
  inputs: ['disabled', 'inverted', 'maxTime', 'minTime', 'value']
})
@Component({
  selector: 'bal-timeinput',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['disabled', 'inverted', 'maxTime', 'minTime', 'value'],
  outputs: ['balChange', 'balBlur']
})
export class BalTimeinput {
  /** Emitted when either the hour or the minute input has changed.
It will not be triggered if either hour or time input has never been set (i.e. "--" is selected). */
  balChange!: EventEmitter<CustomEvent<string>>;
  /** Emitted when either the hour or minute input field loses focus. */
  balBlur!: EventEmitter<CustomEvent<FocusEvent>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balChange', 'balBlur']);
  }
}


export declare interface BalToast extends Components.BalToast {}
@ProxyCmp({
  inputs: ['color', 'duration', 'message'],
  methods: ['closeIn', 'close']
})
@Component({
  selector: 'bal-toast',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: '<ng-content></ng-content>',
  inputs: ['color', 'duration', 'message'],
  outputs: ['balClose']
})
export class BalToast {
  /** Emitted when toast is closed */
  balClose!: EventEmitter<CustomEvent<string>>;
  protected el: HTMLElement;
  constructor(c: ChangeDetectorRef, r: ElementRef, protected z: NgZone) {
    c.detach();
    this.el = r.nativeElement;
    proxyOutputs(this, this.el, ['balClose']);
  }
}




@NgModule({
  declarations: [BalAccordion],
  exports: [BalAccordion],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalAccordionModule {
  constructor() {
    defineBalAccordion();
  }
}




@NgModule({
  declarations: [BalApp],
  exports: [BalApp],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalAppModule {
  constructor() {
    defineBalApp();
  }
}




@NgModule({
  declarations: [BalBadge],
  exports: [BalBadge],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalBadgeModule {
  constructor() {
    defineBalBadge();
  }
}




@NgModule({
  declarations: [BalButton, BalButtonGroup],
  exports: [BalButton, BalButtonGroup],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalButtonModule {
  constructor() {
    defineBalButton();
     defineBalButtonGroup();
  }
}





@NgModule({
  declarations: [BalCard, BalCardTitle, BalCardSubtitle, BalCardContent, BalCardActions, BalCardButton],
  exports: [BalCard, BalCardTitle, BalCardSubtitle, BalCardContent, BalCardActions, BalCardButton],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalCardModule {
  constructor() {
    defineBalCard();
     defineBalCardTitle();
     defineBalCardSubtitle();
     defineBalCardContent();
     defineBalCardActions();
     defineBalCardButton();
  }
}









@NgModule({
  declarations: [BalCheckbox, BalCheckboxGroup],
  exports: [BalCheckbox, BalCheckboxGroup],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalCheckboxModule {
  constructor() {
    defineBalCheckbox();
     defineBalCheckboxGroup();
  }
}





@NgModule({
  declarations: [BalClose],
  exports: [BalClose],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalCloseModule {
  constructor() {
    defineBalClose();
  }
}




@NgModule({
  declarations: [BalData, BalDataItem, BalDataLabel, BalDataValue],
  exports: [BalData, BalDataItem, BalDataLabel, BalDataValue],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalDataModule {
  constructor() {
    defineBalData();
     defineBalDataItem();
     defineBalDataLabel();
     defineBalDataValue();
  }
}







@NgModule({
  declarations: [BalDatepicker],
  exports: [BalDatepicker],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalDatepickerModule {
  constructor() {
    defineBalDatepicker();
  }
}


import { BalNgErrorComponent } from '../components/error/error.component'

@NgModule({
  declarations: [BalField, BalFieldLabel, BalFieldControl, BalFieldHint, BalFieldMessage, BalNgErrorComponent],
  exports: [BalField, BalFieldLabel, BalFieldControl, BalFieldHint, BalFieldMessage, BalNgErrorComponent],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalFieldModule {
  constructor() {
    defineBalField();
     defineBalFieldLabel();
     defineBalFieldControl();
     defineBalFieldHint();
     defineBalFieldMessage();
  }
}








@NgModule({
  declarations: [BalFileUpload],
  exports: [BalFileUpload],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalFileUploadModule {
  constructor() {
    defineBalFileUpload();
  }
}




@NgModule({
  declarations: [BalFooter],
  exports: [BalFooter],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalFooterModule {
  constructor() {
    defineBalFooter();
  }
}




@NgModule({
  declarations: [BalHeading],
  exports: [BalHeading],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalHeadingModule {
  constructor() {
    defineBalHeading();
  }
}




@NgModule({
  declarations: [BalHint, BalHintTitle, BalHintText],
  exports: [BalHint, BalHintTitle, BalHintText],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalHintModule {
  constructor() {
    defineBalHint();
     defineBalHintTitle();
     defineBalHintText();
  }
}






@NgModule({
  declarations: [BalIcon],
  exports: [BalIcon],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalIconModule {
  constructor() {
    defineBalIcon();
  }
}




@NgModule({
  declarations: [BalInput],
  exports: [BalInput],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalInputModule {
  constructor() {
    defineBalInput();
  }
}




@NgModule({
  declarations: [BalInputGroup],
  exports: [BalInputGroup],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalInputGroupModule {
  constructor() {
    defineBalInputGroup();
  }
}




@NgModule({
  declarations: [BalInputStepper],
  exports: [BalInputStepper],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalInputStepperModule {
  constructor() {
    defineBalInputStepper();
  }
}




@NgModule({
  declarations: [BalList, BalListItem, BalListItemTitle, BalListItemSubtitle, BalListItemContent, BalListItemIcon],
  exports: [BalList, BalListItem, BalListItemTitle, BalListItemSubtitle, BalListItemContent, BalListItemIcon],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalListModule {
  constructor() {
    defineBalList();
     defineBalListItem();
     defineBalListItemTitle();
     defineBalListItemSubtitle();
     defineBalListItemContent();
     defineBalListItemIcon();
  }
}









@NgModule({
  declarations: [BalLogo],
  exports: [BalLogo],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalLogoModule {
  constructor() {
    defineBalLogo();
  }
}

import { BalModalService } from '../overlays/modal.service'


@NgModule({
  declarations: [BalModal, BalModalHeader, BalModalBody],
  exports: [BalModal, BalModalHeader, BalModalBody],
  providers: [BalModalService],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalModalModule {
  constructor() {
    defineBalModal();
     defineBalModalHeader();
     defineBalModalBody();
  }
}






@NgModule({
  declarations: [BalNavbar, BalNavbarBrand, BalNavbarMenu, BalNavbarMenuStart, BalNavbarMenuEnd],
  exports: [BalNavbar, BalNavbarBrand, BalNavbarMenu, BalNavbarMenuStart, BalNavbarMenuEnd],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalNavbarModule {
  constructor() {
    defineBalNavbar();
     defineBalNavbarBrand();
     defineBalNavbarMenu();
     defineBalNavbarMenuStart();
     defineBalNavbarMenuEnd();
  }
}








@NgModule({
  declarations: [BalNotices],
  exports: [BalNotices],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalNoticesModule {
  constructor() {
    defineBalNotices();
  }
}




@NgModule({
  declarations: [BalNotification],
  exports: [BalNotification],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalNotificationModule {
  constructor() {
    defineBalNotification();
  }
}




@NgModule({
  declarations: [BalNumberInput],
  exports: [BalNumberInput],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalNumberInputModule {
  constructor() {
    defineBalNumberInput();
  }
}




@NgModule({
  declarations: [BalPagination],
  exports: [BalPagination],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalPaginationModule {
  constructor() {
    defineBalPagination();
  }
}




@NgModule({
  declarations: [BalPopover, BalPopoverContent],
  exports: [BalPopover, BalPopoverContent],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalPopoverModule {
  constructor() {
    defineBalPopover();
     defineBalPopoverContent();
  }
}





@NgModule({
  declarations: [BalRadio, BalRadioGroup],
  exports: [BalRadio, BalRadioGroup],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalRadioModule {
  constructor() {
    defineBalRadio();
     defineBalRadioGroup();
  }
}





@NgModule({
  declarations: [BalSelect, BalSelectOption],
  exports: [BalSelect, BalSelectOption],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalSelectModule {
  constructor() {
    defineBalSelect();
     defineBalSelectOption();
  }
}





@NgModule({
  declarations: [BalSheet],
  exports: [BalSheet],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalSheetModule {
  constructor() {
    defineBalSheet();
  }
}




@NgModule({
  declarations: [BalSlider],
  exports: [BalSlider],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalSliderModule {
  constructor() {
    defineBalSlider();
  }
}

import { BalSnackbarService } from '../overlays/snackbar.service'


@NgModule({
  declarations: [BalSnackbar],
  exports: [BalSnackbar],
  providers: [BalSnackbarService],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalSnackbarModule {
  constructor() {
    defineBalSnackbar();
  }
}




@NgModule({
  declarations: [BalSpinner],
  exports: [BalSpinner],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalSpinnerModule {
  constructor() {
    defineBalSpinner();
  }
}




@NgModule({
  declarations: [BalStage, BalStageBody, BalStageFoot, BalStageHead, BalStageImage],
  exports: [BalStage, BalStageBody, BalStageFoot, BalStageHead, BalStageImage],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalStageModule {
  constructor() {
    defineBalStage();
     defineBalStageBody();
     defineBalStageFoot();
     defineBalStageHead();
     defineBalStageImage();
  }
}









@NgModule({
  declarations: [BalTable],
  exports: [BalTable],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalTableModule {
  constructor() {
    defineBalTable();
  }
}




@NgModule({
  declarations: [BalTabs, BalTabItem],
  exports: [BalTabs, BalTabItem],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalTabsModule {
  constructor() {
    defineBalTabs();
     defineBalTabItem();
  }
}




@NgModule({
  declarations: [BalTag],
  exports: [BalTag],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalTagModule {
  constructor() {
    defineBalTag();
  }
}




@NgModule({
  declarations: [BalText],
  exports: [BalText],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalTextModule {
  constructor() {
    defineBalText();
  }
}




@NgModule({
  declarations: [BalTextarea],
  exports: [BalTextarea],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalTextareaModule {
  constructor() {
    defineBalTextarea();
  }
}




@NgModule({
  declarations: [BalTimeinput],
  exports: [BalTimeinput],
  providers: [],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalTimeinputModule {
  constructor() {
    defineBalTimeinput();
  }
}

import { BalToastService } from '../overlays/toast.service'


@NgModule({
  declarations: [BalToast],
  exports: [BalToast],
  providers: [BalToastService],
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class BalToastModule {
  constructor() {
    defineBalToast();
  }
}
