/* eslint-disable */
/* tslint:disable */
/* auto-generated vue proxies */
import { defineContainer } from './vue-component-lib/utils';

import type { JSX } from '..';

import { defineCustomElement as defineBalAccordion } from '../dist/components/bal-accordion.js';
import { defineCustomElement as defineBalAccordionDetails } from '../dist/components/bal-accordion-details.js';
import { defineCustomElement as defineBalAccordionSummary } from '../dist/components/bal-accordion-summary.js';
import { defineCustomElement as defineBalAccordionTrigger } from '../dist/components/bal-accordion-trigger.js';
import { defineCustomElement as defineBalApp } from '../dist/components/bal-app.js';
import { defineCustomElement as defineBalBadge } from '../dist/components/bal-badge.js';
import { defineCustomElement as defineBalButton } from '../dist/components/bal-button.js';
import { defineCustomElement as defineBalButtonGroup } from '../dist/components/bal-button-group.js';
import { defineCustomElement as defineBalCard } from '../dist/components/bal-card.js';
import { defineCustomElement as defineBalCardActions } from '../dist/components/bal-card-actions.js';
import { defineCustomElement as defineBalCardButton } from '../dist/components/bal-card-button.js';
import { defineCustomElement as defineBalCardContent } from '../dist/components/bal-card-content.js';
import { defineCustomElement as defineBalCardSubtitle } from '../dist/components/bal-card-subtitle.js';
import { defineCustomElement as defineBalCardTitle } from '../dist/components/bal-card-title.js';
import { defineCustomElement as defineBalCarousel } from '../dist/components/bal-carousel.js';
import { defineCustomElement as defineBalCarouselItem } from '../dist/components/bal-carousel-item.js';
import { defineCustomElement as defineBalCheckbox } from '../dist/components/bal-checkbox.js';
import { defineCustomElement as defineBalCheckboxButton } from '../dist/components/bal-checkbox-button.js';
import { defineCustomElement as defineBalCheckboxGroup } from '../dist/components/bal-checkbox-group.js';
import { defineCustomElement as defineBalClose } from '../dist/components/bal-close.js';
import { defineCustomElement as defineBalContent } from '../dist/components/bal-content.js';
import { defineCustomElement as defineBalData } from '../dist/components/bal-data.js';
import { defineCustomElement as defineBalDataItem } from '../dist/components/bal-data-item.js';
import { defineCustomElement as defineBalDataLabel } from '../dist/components/bal-data-label.js';
import { defineCustomElement as defineBalDataValue } from '../dist/components/bal-data-value.js';
import { defineCustomElement as defineBalDatepicker } from '../dist/components/bal-datepicker.js';
import { defineCustomElement as defineBalDivider } from '../dist/components/bal-divider.js';
import { defineCustomElement as defineBalDocApp } from '../dist/components/bal-doc-app.js';
import { defineCustomElement as defineBalDocBanner } from '../dist/components/bal-doc-banner.js';
import { defineCustomElement as defineBalDocCodeSandbox } from '../dist/components/bal-doc-code-sandbox.js';
import { defineCustomElement as defineBalDocColor } from '../dist/components/bal-doc-color.js';
import { defineCustomElement as defineBalDocDownload } from '../dist/components/bal-doc-download.js';
import { defineCustomElement as defineBalDocGithub } from '../dist/components/bal-doc-github.js';
import { defineCustomElement as defineBalDocIcons } from '../dist/components/bal-doc-icons.js';
import { defineCustomElement as defineBalDocImage } from '../dist/components/bal-doc-image.js';
import { defineCustomElement as defineBalDocLead } from '../dist/components/bal-doc-lead.js';
import { defineCustomElement as defineBalDocLinkList } from '../dist/components/bal-doc-link-list.js';
import { defineCustomElement as defineBalDocLinkListItem } from '../dist/components/bal-doc-link-list-item.js';
import { defineCustomElement as defineBalDocPreview } from '../dist/components/bal-doc-preview.js';
import { defineCustomElement as defineBalDocShades } from '../dist/components/bal-doc-shades.js';
import { defineCustomElement as defineBalDocSupportColor } from '../dist/components/bal-doc-support-color.js';
import { defineCustomElement as defineBalDocTokensBorder } from '../dist/components/bal-doc-tokens-border.js';
import { defineCustomElement as defineBalDocTokensBorderColors } from '../dist/components/bal-doc-tokens-border-colors.js';
import { defineCustomElement as defineBalDocTokensBreakpoints } from '../dist/components/bal-doc-tokens-breakpoints.js';
import { defineCustomElement as defineBalDocTokensColors } from '../dist/components/bal-doc-tokens-colors.js';
import { defineCustomElement as defineBalDocTokensContainers } from '../dist/components/bal-doc-tokens-containers.js';
import { defineCustomElement as defineBalDocTokensFont } from '../dist/components/bal-doc-tokens-font.js';
import { defineCustomElement as defineBalDocTokensFontColors } from '../dist/components/bal-doc-tokens-font-colors.js';
import { defineCustomElement as defineBalDocTokensFontSizes } from '../dist/components/bal-doc-tokens-font-sizes.js';
import { defineCustomElement as defineBalDocTokensFontWeight } from '../dist/components/bal-doc-tokens-font-weight.js';
import { defineCustomElement as defineBalDocTokensRadius } from '../dist/components/bal-doc-tokens-radius.js';
import { defineCustomElement as defineBalDocTokensShadow } from '../dist/components/bal-doc-tokens-shadow.js';
import { defineCustomElement as defineBalDocTokensSpacing } from '../dist/components/bal-doc-tokens-spacing.js';
import { defineCustomElement as defineBalDocTokensSpacingSizes } from '../dist/components/bal-doc-tokens-spacing-sizes.js';
import { defineCustomElement as defineBalDocTokensTextShadow } from '../dist/components/bal-doc-tokens-text-shadow.js';
import { defineCustomElement as defineBalField } from '../dist/components/bal-field.js';
import { defineCustomElement as defineBalFieldControl } from '../dist/components/bal-field-control.js';
import { defineCustomElement as defineBalFieldHint } from '../dist/components/bal-field-hint.js';
import { defineCustomElement as defineBalFieldLabel } from '../dist/components/bal-field-label.js';
import { defineCustomElement as defineBalFieldMessage } from '../dist/components/bal-field-message.js';
import { defineCustomElement as defineBalFileUpload } from '../dist/components/bal-file-upload.js';
import { defineCustomElement as defineBalFooter } from '../dist/components/bal-footer.js';
import { defineCustomElement as defineBalForm } from '../dist/components/bal-form.js';
import { defineCustomElement as defineBalFormCol } from '../dist/components/bal-form-col.js';
import { defineCustomElement as defineBalFormGrid } from '../dist/components/bal-form-grid.js';
import { defineCustomElement as defineBalHeading } from '../dist/components/bal-heading.js';
import { defineCustomElement as defineBalHint } from '../dist/components/bal-hint.js';
import { defineCustomElement as defineBalHintText } from '../dist/components/bal-hint-text.js';
import { defineCustomElement as defineBalHintTitle } from '../dist/components/bal-hint-title.js';
import { defineCustomElement as defineBalIcon } from '../dist/components/bal-icon.js';
import { defineCustomElement as defineBalInput } from '../dist/components/bal-input.js';
import { defineCustomElement as defineBalInputGroup } from '../dist/components/bal-input-group.js';
import { defineCustomElement as defineBalInputSlider } from '../dist/components/bal-input-slider.js';
import { defineCustomElement as defineBalInputStepper } from '../dist/components/bal-input-stepper.js';
import { defineCustomElement as defineBalLabel } from '../dist/components/bal-label.js';
import { defineCustomElement as defineBalList } from '../dist/components/bal-list.js';
import { defineCustomElement as defineBalListItem } from '../dist/components/bal-list-item.js';
import { defineCustomElement as defineBalListItemAccordionBody } from '../dist/components/bal-list-item-accordion-body.js';
import { defineCustomElement as defineBalListItemAccordionHead } from '../dist/components/bal-list-item-accordion-head.js';
import { defineCustomElement as defineBalListItemContent } from '../dist/components/bal-list-item-content.js';
import { defineCustomElement as defineBalListItemIcon } from '../dist/components/bal-list-item-icon.js';
import { defineCustomElement as defineBalListItemSubtitle } from '../dist/components/bal-list-item-subtitle.js';
import { defineCustomElement as defineBalListItemTitle } from '../dist/components/bal-list-item-title.js';
import { defineCustomElement as defineBalLogo } from '../dist/components/bal-logo.js';
import { defineCustomElement as defineBalModal } from '../dist/components/bal-modal.js';
import { defineCustomElement as defineBalModalBody } from '../dist/components/bal-modal-body.js';
import { defineCustomElement as defineBalModalHeader } from '../dist/components/bal-modal-header.js';
import { defineCustomElement as defineBalNavbar } from '../dist/components/bal-navbar.js';
import { defineCustomElement as defineBalNavbarBrand } from '../dist/components/bal-navbar-brand.js';
import { defineCustomElement as defineBalNavbarMenu } from '../dist/components/bal-navbar-menu.js';
import { defineCustomElement as defineBalNavbarMenuEnd } from '../dist/components/bal-navbar-menu-end.js';
import { defineCustomElement as defineBalNavbarMenuStart } from '../dist/components/bal-navbar-menu-start.js';
import { defineCustomElement as defineBalNavigation } from '../dist/components/bal-navigation.js';
import { defineCustomElement as defineBalNavigationLevelBlock } from '../dist/components/bal-navigation-level-block.js';
import { defineCustomElement as defineBalNavigationLevelBlockItem } from '../dist/components/bal-navigation-level-block-item.js';
import { defineCustomElement as defineBalNavigationLevelMain } from '../dist/components/bal-navigation-level-main.js';
import { defineCustomElement as defineBalNavigationLevelMeta } from '../dist/components/bal-navigation-level-meta.js';
import { defineCustomElement as defineBalNavigationLevels } from '../dist/components/bal-navigation-levels.js';
import { defineCustomElement as defineBalNavigationMain } from '../dist/components/bal-navigation-main.js';
import { defineCustomElement as defineBalNavigationMainBody } from '../dist/components/bal-navigation-main-body.js';
import { defineCustomElement as defineBalNavigationMainHead } from '../dist/components/bal-navigation-main-head.js';
import { defineCustomElement as defineBalNavigationMenu } from '../dist/components/bal-navigation-menu.js';
import { defineCustomElement as defineBalNavigationMenuList } from '../dist/components/bal-navigation-menu-list.js';
import { defineCustomElement as defineBalNavigationMenuListItem } from '../dist/components/bal-navigation-menu-list-item.js';
import { defineCustomElement as defineBalNavigationMeta } from '../dist/components/bal-navigation-meta.js';
import { defineCustomElement as defineBalNavigationMetaEnd } from '../dist/components/bal-navigation-meta-end.js';
import { defineCustomElement as defineBalNavigationMetaStart } from '../dist/components/bal-navigation-meta-start.js';
import { defineCustomElement as defineBalNavigationPopover } from '../dist/components/bal-navigation-popover.js';
import { defineCustomElement as defineBalNotices } from '../dist/components/bal-notices.js';
import { defineCustomElement as defineBalNotification } from '../dist/components/bal-notification.js';
import { defineCustomElement as defineBalNumberInput } from '../dist/components/bal-number-input.js';
import { defineCustomElement as defineBalPagination } from '../dist/components/bal-pagination.js';
import { defineCustomElement as defineBalPopover } from '../dist/components/bal-popover.js';
import { defineCustomElement as defineBalPopoverContent } from '../dist/components/bal-popover-content.js';
import { defineCustomElement as defineBalProgressBar } from '../dist/components/bal-progress-bar.js';
import { defineCustomElement as defineBalRadio } from '../dist/components/bal-radio.js';
import { defineCustomElement as defineBalRadioButton } from '../dist/components/bal-radio-button.js';
import { defineCustomElement as defineBalRadioGroup } from '../dist/components/bal-radio-group.js';
import { defineCustomElement as defineBalSelect } from '../dist/components/bal-select.js';
import { defineCustomElement as defineBalSelectOption } from '../dist/components/bal-select-option.js';
import { defineCustomElement as defineBalShape } from '../dist/components/bal-shape.js';
import { defineCustomElement as defineBalSheet } from '../dist/components/bal-sheet.js';
import { defineCustomElement as defineBalSnackbar } from '../dist/components/bal-snackbar.js';
import { defineCustomElement as defineBalSpinner } from '../dist/components/bal-spinner.js';
import { defineCustomElement as defineBalStack } from '../dist/components/bal-stack.js';
import { defineCustomElement as defineBalStage } from '../dist/components/bal-stage.js';
import { defineCustomElement as defineBalStageBackLink } from '../dist/components/bal-stage-back-link.js';
import { defineCustomElement as defineBalStageBody } from '../dist/components/bal-stage-body.js';
import { defineCustomElement as defineBalStageFoot } from '../dist/components/bal-stage-foot.js';
import { defineCustomElement as defineBalStageHead } from '../dist/components/bal-stage-head.js';
import { defineCustomElement as defineBalStageImage } from '../dist/components/bal-stage-image.js';
import { defineCustomElement as defineBalStepItem } from '../dist/components/bal-step-item.js';
import { defineCustomElement as defineBalSteps } from '../dist/components/bal-steps.js';
import { defineCustomElement as defineBalTabItem } from '../dist/components/bal-tab-item.js';
import { defineCustomElement as defineBalTable } from '../dist/components/bal-table.js';
import { defineCustomElement as defineBalTabs } from '../dist/components/bal-tabs.js';
import { defineCustomElement as defineBalTag } from '../dist/components/bal-tag.js';
import { defineCustomElement as defineBalTagGroup } from '../dist/components/bal-tag-group.js';
import { defineCustomElement as defineBalText } from '../dist/components/bal-text.js';
import { defineCustomElement as defineBalTextarea } from '../dist/components/bal-textarea.js';
import { defineCustomElement as defineBalTimeInput } from '../dist/components/bal-time-input.js';
import { defineCustomElement as defineBalToast } from '../dist/components/bal-toast.js';


export const BalAccordion = /*@__PURE__*/ defineContainer<JSX.BalAccordion>('bal-accordion', defineBalAccordion, [
  'active',
  'debounce',
  'openLabel',
  'openIcon',
  'closeLabel',
  'closeIcon',
  'card',
  'version',
  'balChange',
  'balWillAnimate',
  'balDidAnimate'
]);


export const BalAccordionDetails = /*@__PURE__*/ defineContainer<JSX.BalAccordionDetails>('bal-accordion-details', defineBalAccordionDetails, [
  'state',
  'active',
  'animated'
]);


export const BalAccordionSummary = /*@__PURE__*/ defineContainer<JSX.BalAccordionSummary>('bal-accordion-summary', defineBalAccordionSummary, [
  'trigger',
  'active',
  'state'
]);


export const BalAccordionTrigger = /*@__PURE__*/ defineContainer<JSX.BalAccordionTrigger>('bal-accordion-trigger', defineBalAccordionTrigger, [
  'button',
  'openLabel',
  'openIcon',
  'closeLabel',
  'closeIcon',
  'color',
  'size',
  'active',
  'state'
]);


export const BalApp = /*@__PURE__*/ defineContainer<JSX.BalApp>('bal-app', defineBalApp, [
  'mode',
  'animated',
  'ready',
  'balAppLoad'
]);


export const BalBadge = /*@__PURE__*/ defineContainer<JSX.BalBadge>('bal-badge', defineBalBadge, [
  'icon',
  'size',
  'color',
  'position'
]);


export const BalButton = /*@__PURE__*/ defineContainer<JSX.BalButton>('bal-button', defineBalButton, [
  'color',
  'elementType',
  'disabled',
  'size',
  'href',
  'target',
  'rel',
  'download',
  'shadow',
  'square',
  'isActive',
  'expanded',
  'flat',
  'outlined',
  'inverted',
  'loading',
  'rounded',
  'topRounded',
  'bottomRounded',
  'icon',
  'iconTurn',
  'iconRight',
  'noWrap',
  'name',
  'value',
  'balNavigate',
  'balFocus',
  'balBlur',
  'balDidRender'
]);


export const BalButtonGroup = /*@__PURE__*/ defineContainer<JSX.BalButtonGroup>('bal-button-group', defineBalButtonGroup, [
  'position',
  'direction',
  'reverse'
]);


export const BalCard = /*@__PURE__*/ defineContainer<JSX.BalCard>('bal-card', defineBalCard, [
  'border',
  'flat',
  'square',
  'inverted',
  'clickable',
  'selected',
  'fullheight',
  'space',
  'color'
]);


export const BalCardActions = /*@__PURE__*/ defineContainer<JSX.BalCardActions>('bal-card-actions', defineBalCardActions, [
  'position'
]);


export const BalCardButton = /*@__PURE__*/ defineContainer<JSX.BalCardButton>('bal-card-button', defineBalCardButton, [
  'icon',
  'elementType',
  'disabled',
  'href',
  'target',
  'iconRight',
  'loading'
]);


export const BalCardContent = /*@__PURE__*/ defineContainer<JSX.BalCardContent>('bal-card-content', defineBalCardContent);


export const BalCardSubtitle = /*@__PURE__*/ defineContainer<JSX.BalCardSubtitle>('bal-card-subtitle', defineBalCardSubtitle, [
  'inverted',
  'bold',
  'color'
]);


export const BalCardTitle = /*@__PURE__*/ defineContainer<JSX.BalCardTitle>('bal-card-title', defineBalCardTitle, [
  'inverted'
]);


export const BalCarousel = /*@__PURE__*/ defineContainer<JSX.BalCarousel>('bal-carousel', defineBalCarousel, [
  'value',
  'steps',
  'itemsPerView',
  'controls',
  'controlsOverflow',
  'inverted',
  'fullHeight',
  'aspectRatio',
  'interface',
  'controlsSticky',
  'scrollY',
  'border',
  'balChange'
]);


export const BalCarouselItem = /*@__PURE__*/ defineContainer<JSX.BalCarouselItem>('bal-carousel-item', defineBalCarouselItem, [
  'src',
  'label',
  'elementType',
  'name',
  'value',
  'href',
  'target',
  'rel',
  'download',
  'color',
  'balNavigate',
  'balFocus',
  'balBlur'
]);


export const BalCheckbox = /*@__PURE__*/ defineContainer<JSX.BalCheckbox>('bal-checkbox', defineBalCheckbox, [
  'name',
  'label',
  'invisible',
  'labelHidden',
  'flat',
  'interface',
  'value',
  'checked',
  'disabled',
  'readonly',
  'required',
  'hidden',
  'invalid',
  'hovered',
  'pressed',
  'balFocus',
  'balBlur',
  'balChange'
],
'checked', 'balChange');


export const BalCheckboxButton = /*@__PURE__*/ defineContainer<JSX.BalCheckboxButton>('bal-checkbox-button', defineBalCheckboxButton, [
  'invalid',
  'disabled',
  'readonly',
  'color',
  'colSize',
  'colSizeTablet',
  'colSizeMobile',
  'balFocus',
  'balBlur',
  'balFormControlDidLoad'
]);


export const BalCheckboxGroup = /*@__PURE__*/ defineContainer<JSX.BalCheckboxGroup>('bal-checkbox-group', defineBalCheckboxGroup, [
  'options',
  'interface',
  'control',
  'name',
  'vertical',
  'verticalOnMobile',
  'expanded',
  'disabled',
  'readonly',
  'value',
  'columns',
  'columnsTablet',
  'columnsMobile',
  'balChange',
  'balFocus',
  'balBlur'
],
'value', 'balChange');


export const BalClose = /*@__PURE__*/ defineContainer<JSX.BalClose>('bal-close', defineBalClose, [
  'size',
  'inverted'
]);


export const BalContent = /*@__PURE__*/ defineContainer<JSX.BalContent>('bal-content', defineBalContent, [
  'layout',
  'align',
  'space',
  'direction',
  'alignment'
]);


export const BalData = /*@__PURE__*/ defineContainer<JSX.BalData>('bal-data', defineBalData, [
  'border',
  'horizontal'
]);


export const BalDataItem = /*@__PURE__*/ defineContainer<JSX.BalDataItem>('bal-data-item', defineBalDataItem, [
  'disabled',
  'border'
]);


export const BalDataLabel = /*@__PURE__*/ defineContainer<JSX.BalDataLabel>('bal-data-label', defineBalDataLabel, [
  'required'
]);


export const BalDataValue = /*@__PURE__*/ defineContainer<JSX.BalDataValue>('bal-data-value', defineBalDataValue, [
  'editable',
  'disabled',
  'multiline',
  'balClick',
  'balFocus',
  'balBlur'
]);


export const BalDatepicker = /*@__PURE__*/ defineContainer<JSX.BalDatepicker>('bal-datepicker', defineBalDatepicker, [
  'name',
  'invalid',
  'required',
  'disabled',
  'readonly',
  'loading',
  'placeholder',
  'min',
  'max',
  'closeOnSelect',
  'triggerIcon',
  'minYearProp',
  'maxYearProp',
  'debounce',
  'defaultDate',
  'value',
  'allowedDates',
  'balChange',
  'balInput',
  'balBlur',
  'balFocus',
  'balInputClick',
  'balIconClick'
],
'value', 'balChange');


export const BalDivider = /*@__PURE__*/ defineContainer<JSX.BalDivider>('bal-divider', defineBalDivider, [
  'layout',
  'space',
  'color'
]);


export const BalDocApp = /*@__PURE__*/ defineContainer<JSX.BalDocApp>('bal-doc-app', defineBalDocApp, [
  'logComponents',
  'logLifecycle',
  'logEvents',
  'logRender',
  'logCustom',
  'stickyFooter',
  'animated'
]);


export const BalDocBanner = /*@__PURE__*/ defineContainer<JSX.BalDocBanner>('bal-doc-banner', defineBalDocBanner, [
  'subtitle',
  'color',
  'shadowDom'
]);


export const BalDocCodeSandbox = /*@__PURE__*/ defineContainer<JSX.BalDocCodeSandbox>('bal-doc-code-sandbox', defineBalDocCodeSandbox, [
  'fullscreen',
  'framework',
  'modules',
  'template',
  'component',
  'name2',
  'template2',
  'component2',
  'visible',
  'primary',
  'logo',
  'label'
]);


export const BalDocColor = /*@__PURE__*/ defineContainer<JSX.BalDocColor>('bal-doc-color', defineBalDocColor, [
  'inverted',
  'background',
  'color',
  'subject',
  'description'
]);


export const BalDocDownload = /*@__PURE__*/ defineContainer<JSX.BalDocDownload>('bal-doc-download', defineBalDocDownload, [
  'link',
  'iconLeft',
  'iconRight',
  'subject',
  'subtitle'
]);


export const BalDocGithub = /*@__PURE__*/ defineContainer<JSX.BalDocGithub>('bal-doc-github', defineBalDocGithub, [
  'link'
]);


export const BalDocIcons = /*@__PURE__*/ defineContainer<JSX.BalDocIcons>('bal-doc-icons', defineBalDocIcons, [
  'icons'
]);


export const BalDocImage = /*@__PURE__*/ defineContainer<JSX.BalDocImage>('bal-doc-image', defineBalDocImage, [
  'src',
  'text'
]);


export const BalDocLead = /*@__PURE__*/ defineContainer<JSX.BalDocLead>('bal-doc-lead', defineBalDocLead);


export const BalDocLinkList = /*@__PURE__*/ defineContainer<JSX.BalDocLinkList>('bal-doc-link-list', defineBalDocLinkList, [
  'oneColumn'
]);


export const BalDocLinkListItem = /*@__PURE__*/ defineContainer<JSX.BalDocLinkListItem>('bal-doc-link-list-item', defineBalDocLinkListItem, [
  'image',
  'subject',
  'template'
]);


export const BalDocPreview = /*@__PURE__*/ defineContainer<JSX.BalDocPreview>('bal-doc-preview', defineBalDocPreview);


export const BalDocShades = /*@__PURE__*/ defineContainer<JSX.BalDocShades>('bal-doc-shades', defineBalDocShades, [
  'color'
]);


export const BalDocSupportColor = /*@__PURE__*/ defineContainer<JSX.BalDocSupportColor>('bal-doc-support-color', defineBalDocSupportColor, [
  'color'
]);


export const BalDocTokensBorder = /*@__PURE__*/ defineContainer<JSX.BalDocTokensBorder>('bal-doc-tokens-border', defineBalDocTokensBorder);


export const BalDocTokensBorderColors = /*@__PURE__*/ defineContainer<JSX.BalDocTokensBorderColors>('bal-doc-tokens-border-colors', defineBalDocTokensBorderColors, [
  'overview'
]);


export const BalDocTokensBreakpoints = /*@__PURE__*/ defineContainer<JSX.BalDocTokensBreakpoints>('bal-doc-tokens-breakpoints', defineBalDocTokensBreakpoints);


export const BalDocTokensColors = /*@__PURE__*/ defineContainer<JSX.BalDocTokensColors>('bal-doc-tokens-colors', defineBalDocTokensColors);


export const BalDocTokensContainers = /*@__PURE__*/ defineContainer<JSX.BalDocTokensContainers>('bal-doc-tokens-containers', defineBalDocTokensContainers);


export const BalDocTokensFont = /*@__PURE__*/ defineContainer<JSX.BalDocTokensFont>('bal-doc-tokens-font', defineBalDocTokensFont);


export const BalDocTokensFontColors = /*@__PURE__*/ defineContainer<JSX.BalDocTokensFontColors>('bal-doc-tokens-font-colors', defineBalDocTokensFontColors);


export const BalDocTokensFontSizes = /*@__PURE__*/ defineContainer<JSX.BalDocTokensFontSizes>('bal-doc-tokens-font-sizes', defineBalDocTokensFontSizes);


export const BalDocTokensFontWeight = /*@__PURE__*/ defineContainer<JSX.BalDocTokensFontWeight>('bal-doc-tokens-font-weight', defineBalDocTokensFontWeight);


export const BalDocTokensRadius = /*@__PURE__*/ defineContainer<JSX.BalDocTokensRadius>('bal-doc-tokens-radius', defineBalDocTokensRadius);


export const BalDocTokensShadow = /*@__PURE__*/ defineContainer<JSX.BalDocTokensShadow>('bal-doc-tokens-shadow', defineBalDocTokensShadow);


export const BalDocTokensSpacing = /*@__PURE__*/ defineContainer<JSX.BalDocTokensSpacing>('bal-doc-tokens-spacing', defineBalDocTokensSpacing);


export const BalDocTokensSpacingSizes = /*@__PURE__*/ defineContainer<JSX.BalDocTokensSpacingSizes>('bal-doc-tokens-spacing-sizes', defineBalDocTokensSpacingSizes);


export const BalDocTokensTextShadow = /*@__PURE__*/ defineContainer<JSX.BalDocTokensTextShadow>('bal-doc-tokens-text-shadow', defineBalDocTokensTextShadow);


export const BalField = /*@__PURE__*/ defineContainer<JSX.BalField>('bal-field', defineBalField, [
  'required',
  'invalid',
  'valid',
  'disabled',
  'readonly',
  'loading',
  'balFormControlDidLoad'
]);


export const BalFieldControl = /*@__PURE__*/ defineContainer<JSX.BalFieldControl>('bal-field-control', defineBalFieldControl, [
  'iconRight',
  'iconLeft',
  'expandedOnMobile',
  'loading'
]);


export const BalFieldHint = /*@__PURE__*/ defineContainer<JSX.BalFieldHint>('bal-field-hint', defineBalFieldHint, [
  'subject',
  'closeLabel',
  'small'
]);


export const BalFieldLabel = /*@__PURE__*/ defineContainer<JSX.BalFieldLabel>('bal-field-label', defineBalFieldLabel, [
  'htmlFor',
  'required',
  'valid',
  'invalid',
  'disabled',
  'readonly',
  'weight'
]);


export const BalFieldMessage = /*@__PURE__*/ defineContainer<JSX.BalFieldMessage>('bal-field-message', defineBalFieldMessage, [
  'color',
  'invalid',
  'valid',
  'disabled',
  'readonly'
]);


export const BalFileUpload = /*@__PURE__*/ defineContainer<JSX.BalFileUpload>('bal-file-upload', defineBalFileUpload, [
  'name',
  'value',
  'label',
  'multiple',
  'disabled',
  'readonly',
  'loading',
  'required',
  'accept',
  'maxFiles',
  'maxFileSize',
  'maxBundleSize',
  'hasFileList',
  'invalid',
  'subTitle',
  'balChange',
  'balFilesAdded',
  'balFilesRemoved',
  'balRejectedFile',
  'balInputClick',
  'balBlur',
  'balFocus'
]);


export const BalFooter = /*@__PURE__*/ defineContainer<JSX.BalFooter>('bal-footer', defineBalFooter, [
  'hideLinks',
  'showSocialMedia',
  'hideLanguageSelection'
]);


export const BalForm = /*@__PURE__*/ defineContainer<JSX.BalForm>('bal-form', defineBalForm, [
  'native',
  'novalidate'
]);


export const BalFormCol = /*@__PURE__*/ defineContainer<JSX.BalFormCol>('bal-form-col', defineBalFormCol, [
  'size'
]);


export const BalFormGrid = /*@__PURE__*/ defineContainer<JSX.BalFormGrid>('bal-form-grid', defineBalFormGrid);


export const BalHeading = /*@__PURE__*/ defineContainer<JSX.BalHeading>('bal-heading', defineBalHeading, [
  'level',
  'visualLevel',
  'autoLevel',
  'noWrap',
  'subtitle',
  'space',
  'color',
  'inverted',
  'shadow'
]);


export const BalHint = /*@__PURE__*/ defineContainer<JSX.BalHint>('bal-hint', defineBalHint, [
  'closeLabel',
  'small'
]);


export const BalHintText = /*@__PURE__*/ defineContainer<JSX.BalHintText>('bal-hint-text', defineBalHintText);


export const BalHintTitle = /*@__PURE__*/ defineContainer<JSX.BalHintTitle>('bal-hint-title', defineBalHintTitle);


export const BalIcon = /*@__PURE__*/ defineContainer<JSX.BalIcon>('bal-icon', defineBalIcon, [
  'name',
  'svg',
  'size',
  'color',
  'inline',
  'inverted',
  'turn',
  'shadow',
  'disabled',
  'invalid',
  'hovered',
  'pressed'
]);


export const BalInput = /*@__PURE__*/ defineContainer<JSX.BalInput>('bal-input', defineBalInput, [
  'name',
  'invalid',
  'textAlign',
  'type',
  'accept',
  'autocapitalize',
  'autocomplete',
  'autocorrect',
  'autofocus',
  'debounce',
  'placeholder',
  'max',
  'maxLength',
  'min',
  'minLength',
  'multiple',
  'pattern',
  'allowedKeyPress',
  'required',
  'spellcheck',
  'disabled',
  'readonly',
  'clickable',
  'suffix',
  'hasIconRight',
  'inputmode',
  'value',
  'mask',
  'balInput',
  'balBlur',
  'balKeyPress',
  'balFocus',
  'balChange'
],
'value', 'balInput');


export const BalInputGroup = /*@__PURE__*/ defineContainer<JSX.BalInputGroup>('bal-input-group', defineBalInputGroup, [
  'invalid',
  'disabled',
  'readonly'
]);


export const BalInputSlider = /*@__PURE__*/ defineContainer<JSX.BalInputSlider>('bal-input-slider', defineBalInputSlider, [
  'name',
  'step',
  'min',
  'max',
  'balTabindex',
  'disabled',
  'readonly',
  'required',
  'hasTicks',
  'debounce',
  'value',
  'balInput',
  'balBlur',
  'balKeyPress',
  'balFocus',
  'balChange'
],
'value', 'balInput');


export const BalInputStepper = /*@__PURE__*/ defineContainer<JSX.BalInputStepper>('bal-input-stepper', defineBalInputStepper, [
  'name',
  'min',
  'max',
  'steps',
  'disabled',
  'readonly',
  'invalid',
  'debounce',
  'value',
  'balChange',
  'balInput',
  'balIncrease',
  'balDecrease'
],
'value', 'balChange');


export const BalLabel = /*@__PURE__*/ defineContainer<JSX.BalLabel>('bal-label', defineBalLabel, [
  'htmlFor',
  'required',
  'noWrap',
  'multiline',
  'valid',
  'invalid',
  'disabled',
  'readonly',
  'size',
  'weight',
  'hovered',
  'pressed'
]);


export const BalList = /*@__PURE__*/ defineContainer<JSX.BalList>('bal-list', defineBalList, [
  'disabled',
  'background',
  'border',
  'accordionOneLevel',
  'size'
]);


export const BalListItem = /*@__PURE__*/ defineContainer<JSX.BalListItem>('bal-list-item', defineBalListItem, [
  'disabled',
  'clickable',
  'selected',
  'accordion',
  'subAccordionItem',
  'href',
  'target',
  'download',
  'balNavigate',
  'balGroupStateChanged',
  'balWillAnimate',
  'balDidAnimate'
]);


export const BalListItemAccordionBody = /*@__PURE__*/ defineContainer<JSX.BalListItemAccordionBody>('bal-list-item-accordion-body', defineBalListItemAccordionBody, [
  'accordionGroup',
  'contentSpace',
  'contentAlignment'
]);


export const BalListItemAccordionHead = /*@__PURE__*/ defineContainer<JSX.BalListItemAccordionHead>('bal-list-item-accordion-head', defineBalListItemAccordionHead, [
  'accordionOpen',
  'icon',
  'balAccordionChange'
]);


export const BalListItemContent = /*@__PURE__*/ defineContainer<JSX.BalListItemContent>('bal-list-item-content', defineBalListItemContent, [
  'contentAlignment'
]);


export const BalListItemIcon = /*@__PURE__*/ defineContainer<JSX.BalListItemIcon>('bal-list-item-icon', defineBalListItemIcon, [
  'right'
]);


export const BalListItemSubtitle = /*@__PURE__*/ defineContainer<JSX.BalListItemSubtitle>('bal-list-item-subtitle', defineBalListItemSubtitle);


export const BalListItemTitle = /*@__PURE__*/ defineContainer<JSX.BalListItemTitle>('bal-list-item-title', defineBalListItemTitle, [
  'level',
  'visualLevel'
]);


export const BalLogo = /*@__PURE__*/ defineContainer<JSX.BalLogo>('bal-logo', defineBalLogo, [
  'color',
  'animated'
]);


export const BalModal = /*@__PURE__*/ defineContainer<JSX.BalModal>('bal-modal', defineBalModal, [
  'overlayIndex',
  'delegate',
  'dataTestId',
  'modalWidth',
  'space',
  'hasBackdrop',
  'isClosable',
  'component',
  'componentProps',
  'cssClass',
  'backdropDismiss',
  'balModalDidPresent',
  'balModalWillPresent',
  'balModalWillDismiss',
  'balModalDidDismiss'
]);


export const BalModalBody = /*@__PURE__*/ defineContainer<JSX.BalModalBody>('bal-modal-body', defineBalModalBody);


export const BalModalHeader = /*@__PURE__*/ defineContainer<JSX.BalModalHeader>('bal-modal-header', defineBalModalHeader);


export const BalNavbar = /*@__PURE__*/ defineContainer<JSX.BalNavbar>('bal-navbar', defineBalNavbar, [
  'light',
  'interface',
  'container'
]);


export const BalNavbarBrand = /*@__PURE__*/ defineContainer<JSX.BalNavbarBrand>('bal-navbar-brand', defineBalNavbarBrand, [
  'href',
  'target',
  'simple',
  'logo',
  'animated',
  'interface',
  'balNavigate',
  'balWillAnimate',
  'balDidAnimate'
]);


export const BalNavbarMenu = /*@__PURE__*/ defineContainer<JSX.BalNavbarMenu>('bal-navbar-menu', defineBalNavbarMenu, [
  'interface'
]);


export const BalNavbarMenuEnd = /*@__PURE__*/ defineContainer<JSX.BalNavbarMenuEnd>('bal-navbar-menu-end', defineBalNavbarMenuEnd, [
  'interface'
]);


export const BalNavbarMenuStart = /*@__PURE__*/ defineContainer<JSX.BalNavbarMenuStart>('bal-navbar-menu-start', defineBalNavbarMenuStart, [
  'interface'
]);


export const BalNavigation = /*@__PURE__*/ defineContainer<JSX.BalNavigation>('bal-navigation', defineBalNavigation, [
  'logoAnimated',
  'logoPath',
  'ariaLabelMeta',
  'ariaLabelMain',
  'metaValue'
]);


export const BalNavigationLevelBlock = /*@__PURE__*/ defineContainer<JSX.BalNavigationLevelBlock>('bal-navigation-level-block', defineBalNavigationLevelBlock, [
  'label',
  'value',
  'color',
  'link',
  'linkLabel',
  'target',
  'balClick'
]);


export const BalNavigationLevelBlockItem = /*@__PURE__*/ defineContainer<JSX.BalNavigationLevelBlockItem>('bal-navigation-level-block-item', defineBalNavigationLevelBlockItem, [
  'label',
  'value',
  'link',
  'linkLabel',
  'target',
  'balClick'
]);


export const BalNavigationLevelMain = /*@__PURE__*/ defineContainer<JSX.BalNavigationLevelMain>('bal-navigation-level-main', defineBalNavigationLevelMain, [
  'label',
  'value',
  'link',
  'linkLabel',
  'isTabLink',
  'target',
  'balClick'
]);


export const BalNavigationLevelMeta = /*@__PURE__*/ defineContainer<JSX.BalNavigationLevelMeta>('bal-navigation-level-meta', defineBalNavigationLevelMeta, [
  'label',
  'value',
  'link',
  'linkLabel',
  'isTabLink',
  'balClick'
]);


export const BalNavigationLevels = /*@__PURE__*/ defineContainer<JSX.BalNavigationLevels>('bal-navigation-levels', defineBalNavigationLevels);


export const BalNavigationMain = /*@__PURE__*/ defineContainer<JSX.BalNavigationMain>('bal-navigation-main', defineBalNavigationMain, [
  'ariaLabelMain'
]);


export const BalNavigationMainBody = /*@__PURE__*/ defineContainer<JSX.BalNavigationMainBody>('bal-navigation-main-body', defineBalNavigationMainBody);


export const BalNavigationMainHead = /*@__PURE__*/ defineContainer<JSX.BalNavigationMainHead>('bal-navigation-main-head', defineBalNavigationMainHead);


export const BalNavigationMenu = /*@__PURE__*/ defineContainer<JSX.BalNavigationMenu>('bal-navigation-menu', defineBalNavigationMenu, [
  'linkHref',
  'linkName',
  'target',
  'elements',
  'tracking'
]);


export const BalNavigationMenuList = /*@__PURE__*/ defineContainer<JSX.BalNavigationMenuList>('bal-navigation-menu-list', defineBalNavigationMenuList, [
  'color',
  'headline',
  'href',
  'target',
  'tracking'
]);


export const BalNavigationMenuListItem = /*@__PURE__*/ defineContainer<JSX.BalNavigationMenuListItem>('bal-navigation-menu-list-item', defineBalNavigationMenuListItem, [
  'href',
  'tracking',
  'target'
]);


export const BalNavigationMeta = /*@__PURE__*/ defineContainer<JSX.BalNavigationMeta>('bal-navigation-meta', defineBalNavigationMeta, [
  'ariaLabelMeta'
]);


export const BalNavigationMetaEnd = /*@__PURE__*/ defineContainer<JSX.BalNavigationMetaEnd>('bal-navigation-meta-end', defineBalNavigationMetaEnd);


export const BalNavigationMetaStart = /*@__PURE__*/ defineContainer<JSX.BalNavigationMetaStart>('bal-navigation-meta-start', defineBalNavigationMetaStart);


export const BalNavigationPopover = /*@__PURE__*/ defineContainer<JSX.BalNavigationPopover>('bal-navigation-popover', defineBalNavigationPopover, [
  'label',
  'inverted',
  'icon',
  'backdrop',
  'size',
  'inactiveColor',
  'activeColor',
  'heading',
  'closable',
  'contentRadius',
  'position',
  'contentWidth',
  'contentMinWidth',
  'offsetY',
  'square',
  'contentNoShadow',
  'contentExpanded',
  'arrow',
  'mobileTop'
]);


export const BalNotices = /*@__PURE__*/ defineContainer<JSX.BalNotices>('bal-notices', defineBalNotices, [
  'interface'
]);


export const BalNotification = /*@__PURE__*/ defineContainer<JSX.BalNotification>('bal-notification', defineBalNotification, [
  'color'
]);


export const BalNumberInput = /*@__PURE__*/ defineContainer<JSX.BalNumberInput>('bal-number-input', defineBalNumberInput, [
  'name',
  'invalid',
  'decimal',
  'suffix',
  'placeholder',
  'required',
  'disabled',
  'readonly',
  'exactNumber',
  'max',
  'min',
  'debounce',
  'value',
  'balInput',
  'balChange',
  'balBlur',
  'balFocus',
  'balKeyPress'
],
'value', 'balInput');


export const BalPagination = /*@__PURE__*/ defineContainer<JSX.BalPagination>('bal-pagination', defineBalPagination, [
  'interface',
  'disabled',
  'value',
  'totalPages',
  'pageRange',
  'sticky',
  'top',
  'balChange'
]);


export const BalPopover = /*@__PURE__*/ defineContainer<JSX.BalPopover>('bal-popover', defineBalPopover, [
  'autoTrigger',
  'hint',
  'hover',
  'arrow',
  'backdrop',
  'tooltip',
  'offsetX',
  'offsetY',
  'padding',
  'position',
  'active',
  'mobileTop',
  'balChange',
  'balWillAnimate',
  'balDidAnimate',
  'balPopoverPrepare'
]);


export const BalPopoverContent = /*@__PURE__*/ defineContainer<JSX.BalPopoverContent>('bal-popover-content', defineBalPopoverContent, [
  'spaceless',
  'scrollable',
  'contentWidth',
  'contentMinWidth',
  'color',
  'expanded',
  'radius',
  'noShadow',
  'mobileTop'
]);


export const BalProgressBar = /*@__PURE__*/ defineContainer<JSX.BalProgressBar>('bal-progress-bar', defineBalProgressBar, [
  'value',
  'background'
]);


export const BalRadio = /*@__PURE__*/ defineContainer<JSX.BalRadio>('bal-radio', defineBalRadio, [
  'name',
  'value',
  'label',
  'invisible',
  'labelHidden',
  'flat',
  'interface',
  'disabled',
  'readonly',
  'required',
  'hidden',
  'invalid',
  'hovered',
  'pressed',
  'balFocus',
  'balBlur',
  'balChange'
]);


export const BalRadioButton = /*@__PURE__*/ defineContainer<JSX.BalRadioButton>('bal-radio-button', defineBalRadioButton, [
  'invalid',
  'disabled',
  'readonly',
  'color',
  'colSize',
  'colSizeTablet',
  'colSizeMobile',
  'balFocus',
  'balBlur',
  'balFormControlDidLoad'
]);


export const BalRadioGroup = /*@__PURE__*/ defineContainer<JSX.BalRadioGroup>('bal-radio-group', defineBalRadioGroup, [
  'options',
  'allowEmptySelection',
  'name',
  'value',
  'interface',
  'vertical',
  'verticalOnMobile',
  'expanded',
  'invalid',
  'disabled',
  'readonly',
  'columns',
  'columnsTablet',
  'columnsMobile',
  'balChange',
  'balFocus',
  'balBlur'
],
'value', 'balChange');


export const BalSelect = /*@__PURE__*/ defineContainer<JSX.BalSelect>('bal-select', defineBalSelect, [
  'name',
  'invalid',
  'filter',
  'balTabindex',
  'freeSolo',
  'multiple',
  'maxLength',
  'noDataLabel',
  'autocomplete',
  'typeahead',
  'selectionOptional',
  'disabled',
  'readonly',
  'required',
  'inverted',
  'placeholder',
  'scrollable',
  'loading',
  'remote',
  'value',
  'balChange',
  'balInputClick',
  'balInput',
  'balBlur',
  'balFocus',
  'balCancel',
  'balKeyPress'
],
'value', 'balChange');


export const BalSelectOption = /*@__PURE__*/ defineContainer<JSX.BalSelectOption>('bal-select-option', defineBalSelectOption, [
  'label',
  'disabled',
  'value',
  'for'
]);


export const BalShape = /*@__PURE__*/ defineContainer<JSX.BalShape>('bal-shape', defineBalShape, [
  'variation',
  'color',
  'rotation'
]);


export const BalSheet = /*@__PURE__*/ defineContainer<JSX.BalSheet>('bal-sheet', defineBalSheet, [
  'containerSize'
]);


export const BalSnackbar = /*@__PURE__*/ defineContainer<JSX.BalSnackbar>('bal-snackbar', defineBalSnackbar, [
  'color',
  'duration',
  'subject',
  'message',
  'icon',
  'action',
  'closeHandler',
  'actionHandler',
  'href',
  'target',
  'balClose',
  'balAction'
]);


export const BalSpinner = /*@__PURE__*/ defineContainer<JSX.BalSpinner>('bal-spinner', defineBalSpinner, [
  'inverted',
  'deactivated',
  'color',
  'small'
]);


export const BalStack = /*@__PURE__*/ defineContainer<JSX.BalStack>('bal-stack', defineBalStack, [
  'layout',
  'align',
  'space',
  'px',
  'py',
  'useWrap',
  'direction',
  'alignment'
]);


export const BalStage = /*@__PURE__*/ defineContainer<JSX.BalStage>('bal-stage', defineBalStage, [
  'containerSize',
  'size',
  'color',
  'shape',
  'shapeVariation',
  'shapeRotation'
]);


export const BalStageBackLink = /*@__PURE__*/ defineContainer<JSX.BalStageBackLink>('bal-stage-back-link', defineBalStageBackLink, [
  'href',
  'shadow',
  'inverted'
]);


export const BalStageBody = /*@__PURE__*/ defineContainer<JSX.BalStageBody>('bal-stage-body', defineBalStageBody);


export const BalStageFoot = /*@__PURE__*/ defineContainer<JSX.BalStageFoot>('bal-stage-foot', defineBalStageFoot);


export const BalStageHead = /*@__PURE__*/ defineContainer<JSX.BalStageHead>('bal-stage-head', defineBalStageHead);


export const BalStageImage = /*@__PURE__*/ defineContainer<JSX.BalStageImage>('bal-stage-image', defineBalStageImage, [
  'srcSet',
  'fallback'
]);


export const BalStepItem = /*@__PURE__*/ defineContainer<JSX.BalStepItem>('bal-step-item', defineBalStepItem, [
  'active',
  'value',
  'label',
  'href',
  'target',
  'disabled',
  'done',
  'hidden',
  'failed',
  'prevent',
  'balNavigate'
]);


export const BalSteps = /*@__PURE__*/ defineContainer<JSX.BalSteps>('bal-steps', defineBalSteps, [
  'options',
  'clickable',
  'debounce',
  'value',
  'balChange'
]);


export const BalTabItem = /*@__PURE__*/ defineContainer<JSX.BalTabItem>('bal-tab-item', defineBalTabItem, [
  'active',
  'value',
  'label',
  'href',
  'target',
  'bubble',
  'disabled',
  'hidden',
  'prevent',
  'icon',
  'balNavigate'
]);


export const BalTable = /*@__PURE__*/ defineContainer<JSX.BalTable>('bal-table', defineBalTable, [
  'expanded'
]);


export const BalTabs = /*@__PURE__*/ defineContainer<JSX.BalTabs>('bal-tabs', defineBalTabs, [
  'float',
  'fullwidth',
  'accordion',
  'overflow',
  'options',
  'context',
  'iconPosition',
  'expanded',
  'spaceless',
  'clickable',
  'border',
  'inverted',
  'debounce',
  'vertical',
  'verticalColSize',
  'selectOnMobile',
  'value',
  'balChange',
  'balWillAnimate',
  'balDidAnimate'
],
'value', 'balChange');


export const BalTag = /*@__PURE__*/ defineContainer<JSX.BalTag>('bal-tag', defineBalTag, [
  'color',
  'size',
  'closable',
  'invalid',
  'disabled',
  'position',
  'light',
  'transparent',
  'balCloseClick'
]);


export const BalTagGroup = /*@__PURE__*/ defineContainer<JSX.BalTagGroup>('bal-tag-group', defineBalTagGroup);


export const BalText = /*@__PURE__*/ defineContainer<JSX.BalText>('bal-text', defineBalText, [
  'size',
  'heading',
  'noWrap',
  'bold',
  'inline',
  'color',
  'space',
  'inverted',
  'shadow',
  'disabled',
  'invalid',
  'hovered',
  'pressed'
]);


export const BalTextarea = /*@__PURE__*/ defineContainer<JSX.BalTextarea>('bal-textarea', defineBalTextarea, [
  'name',
  'invalid',
  'autocapitalize',
  'autofocus',
  'debounce',
  'placeholder',
  'maxLength',
  'minLength',
  'disabled',
  'readonly',
  'cols',
  'rows',
  'wrap',
  'required',
  'clickable',
  'inputmode',
  'value',
  'balChange',
  'balInput',
  'balBlur',
  'balKeyPress',
  'balFocus'
],
'value', 'balInput');


export const BalTimeInput = /*@__PURE__*/ defineContainer<JSX.BalTimeInput>('bal-time-input', defineBalTimeInput, [
  'name',
  'invalid',
  'required',
  'disabled',
  'readonly',
  'debounce',
  'value',
  'balInput',
  'balChange',
  'balBlur',
  'balFocus',
  'balKeyPress',
  'balClick'
]);


export const BalToast = /*@__PURE__*/ defineContainer<JSX.BalToast>('bal-toast', defineBalToast, [
  'color',
  'duration',
  'message',
  'closeHandler',
  'balClose'
]);

